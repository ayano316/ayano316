document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const authSection = document.getElementById('auth-section');
    const loginForm = document.getElementById('login-form');
    const userProfile = document.getElementById('user-profile');
    const emailInput = document.getElementById('auth-email');
    const passwordInput = document.getElementById('auth-password');
    const emailLoginBtn = document.getElementById('email-login-btn');
    const emailSignupBtn = document.getElementById('email-signup-btn');
    const googleLoginBtn = document.getElementById('google-login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const userNameDisplay = document.getElementById('user-name-display');
    const userEmailDisplay = document.getElementById('user-email-display');
    const lastOrderDisplay = document.getElementById('last-order-display');
    const authStatus = document.getElementById('auth-status');

    // Google Auth Provider
    const googleProvider = new firebase.auth.GoogleAuthProvider();

    // Helper function to show/hide sections
    const updateUI = (user) => {
        if (user) {
            loginForm.classList.add('hidden');
            userProfile.classList.remove('hidden');
            userNameDisplay.textContent = user.displayName || 'مستخدم';
            userEmailDisplay.textContent = user.email;
            authStatus.classList.add('hidden');
            fetchLastOrder(user.uid);
        } else {
            loginForm.classList.remove('hidden');
            userProfile.classList.add('hidden');
            authStatus.classList.remove('hidden');
        }
    };

    // Fetch last order time from Realtime Database
    const fetchLastOrder = async (uid) => {
        try {
            const userSnapshot = await window.db.ref('users/' + uid).once('value');
            if (userSnapshot.exists()) {
                const userData = userSnapshot.val();
                const lastOrderTime = userData.lastOrderTime;
                if (lastOrderTime) {
                    const date = new Date(lastOrderTime);
                    lastOrderDisplay.textContent = date.toLocaleString('ar-EG', {
                        year: 'numeric', month: 'long', day: 'numeric',
                        hour: 'numeric', minute: 'numeric'
                    });
                }
            }
        } catch (error) {
            console.error("Error fetching last order time:", error);
        }
    };

    // Event Listeners
    emailLoginBtn.addEventListener('click', () => {
        window.auth.signInWithEmailAndPassword(emailInput.value, passwordInput.value)
            .then(() => alert('تم تسجيل الدخول بنجاح!'))
            .catch(error => alert(error.message));
    });

    emailSignupBtn.addEventListener('click', () => {
        window.auth.createUserWithEmailAndPassword(emailInput.value, passwordInput.value)
            .then((userCredential) => {
                const user = userCredential.user;
                // Save user data to Realtime Database
                return window.db.ref('users/' + user.uid).set({
                    email: user.email,
                    createdAt: firebase.database.ServerValue.TIMESTAMP
                });
            })
            .then(() => {
                alert('تم إنشاء الحساب بنجاح!');
            })
            .catch(error => alert(error.message));
    });

    googleLoginBtn.addEventListener('click', () => {
        window.auth.signInWithPopup(googleProvider)
            .then((result) => {
                const user = result.user;
                alert('تم تسجيل الدخول بحساب جوجل بنجاح!');
                // Save user data to Realtime Database if it's a new user
                const userRef = window.db.ref('users/' + user.uid);
                userRef.once('value').then((snapshot) => {
                    if (!snapshot.exists()) {
                        userRef.set({
                            email: user.email,
                            displayName: user.displayName,
                            createdAt: firebase.database.ServerValue.TIMESTAMP
                        });
                    }
                });
            })
            .catch(error => alert(error.message));
    });

    logoutBtn.addEventListener('click', () => {
        window.auth.signOut()
            .then(() => alert('تم تسجيل الخروج.'))
            .catch(error => alert(error.message));
    });

    // Auth state change listener
    window.auth.onAuthStateChanged(user => {
        updateUI(user);
    });
});