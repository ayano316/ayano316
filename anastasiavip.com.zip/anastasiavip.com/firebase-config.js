// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDLqM7oSbiJiK1632pegj0tbcJ8Heu9KAg",
    authDomain: "anastasiavi.firebaseapp.com",
    projectId: "anastasiavi",
    storageBucket: "anastasiavi.firebasestorage.app",
    messagingSenderId: "1043463933043",
    appId: "1:1043463933043:web:d61c72abd20e16341bae06",
    measurementId: "G-WS8NR8815Y",
    databaseURL: "https://anastasiavi-default-rtdb.firebaseio.com"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
window.auth = app.auth();
window.db = app.database();