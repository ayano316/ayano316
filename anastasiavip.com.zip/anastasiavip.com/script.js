document.addEventListener('DOMContentLoaded', () => {

    // --- إعدادات خدمة إرسال الإيميلات ---
    const EMAILJS_SERVICE_ID = 'service_gqx702p';
    const EMAILJS_TEMPLATE_ID = 'template_3ti8w4h';
    const EMAILJS_PUBLIC_KEY = '9oYp8QTJFXkmq2TC7';

    // --- الأسعار ---
    const prices = {
        egypt: {
            currency: "EGP",
            diamond: { tier1: "220", tier2: "390", tier3: "1615", tier4: "3230" },
            regular: { tier1: "100", tier2: "200" },
            premium: { tier1: "1940", tier2: "11620" }
        },
        saudi: {
            currency: "SAR",
            diamond: { tier1: "17", tier2: "30", tier3: "125", tier4: "250" },
            regular: { tier1: "15", tier2: "25" },
            premium: { tier1: "150", tier2: "900" }
        },
        other: {
            currency: "USD",
            diamond: { tier1: "4", tier2: "7", tier3: "30", tier4: "60" },
            regular: { tier1: "2", tier2: "4" },
            premium: { tier1: "40", tier2: "235" }
        }
    };

    // --- تهيئة EmailJS ---
    emailjs.init(EMAILJS_PUBLIC_KEY);

    // --- العناصر الأساسية ---
    const welcomeModal = document.getElementById('welcome-modal');
    const countryModal = document.getElementById('country-modal');
    const paymentModal = document.getElementById('payment-modal');
    
    let selectedPackageName = '';
    let selectedPackagePrice = '';
    let selectedPaymentMethod = '';

    const updatePrices = (country) => {
        const countryKey = (['egypt', 'saudi', 'uae', 'kuwait', 'bahrain'].includes(country)) ? country : 'other';
        const pricesData = prices[countryKey] || prices['other'];
        const currency = pricesData.currency;
        document.querySelectorAll('.package-card').forEach(card => {
            const packageId = card.dataset.packageId;
            const packagePrices = pricesData[packageId];
            if (packagePrices) {
                card.querySelectorAll('.price-tier').forEach(tier => {
                    const tierId = tier.dataset.tierId;
                    const priceValue = packagePrices[tierId];
                    if (priceValue) {
                        tier.querySelector('.price').textContent = `${priceValue} ${currency}`;
                        const buyButton = tier.querySelector('.btn');
                        if(buyButton) {
                           buyButton.dataset.price = `${priceValue} ${currency}`;
                        }
                    }
                });
            }
        });
        localStorage.setItem('selectedCountry', countryKey);
    };
    
    const closeModal = () => {
        paymentModal.classList.add('hidden');
        document.body.style.overflow = 'auto';
        document.getElementById('step-1-payment-method').classList.remove('hidden');
        document.getElementById('step-2-payment-instructions').classList.add('hidden');
        document.getElementById('step-3-thank-you').classList.add('hidden');
        document.querySelectorAll('.payment-details input').forEach(input => input.value = '');
        if (typeof grecaptcha !== "undefined") grecaptcha.reset();
    };

    const initializePage = () => {
        const savedCountry = localStorage.getItem('selectedCountry');
        if (savedCountry) {
            updatePrices(savedCountry);
            welcomeModal.classList.add('hidden');
            countryModal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        } else {
            updatePrices('other');
            document.body.style.overflow = 'hidden';
            welcomeModal.classList.remove('hidden');
            countryModal.classList.add('hidden');
        }
    };
    
    initializePage();

    document.body.addEventListener('click', (e) => {
        
        if (e.target.id === 'explore-btn') {
            welcomeModal.classList.add('hidden');
            countryModal.classList.remove('hidden');
        }
        
        if (e.target.classList.contains('country-btn')) {
            const selectedCountry = e.target.dataset.country;
            updatePrices(selectedCountry);
            countryModal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
        
        const buyButton = e.target.closest('.package-card .btn');
        if (buyButton) {
            e.preventDefault();
            selectedPackageName = buyButton.closest('.package-card').dataset.packageName;
            selectedPackagePrice = buyButton.dataset.price;
            
            if (!selectedPackageName || !selectedPackagePrice || selectedPackagePrice.includes('--')) {
                alert('الرجاء اختيار دولتك أولاً.');
                localStorage.removeItem('selectedCountry');
                initializePage();
                return;
            }
            
            const user = window.auth.currentUser;
            if (!user) {
                alert('الرجاء تسجيل الدخول أولاً لإتمام عملية الشراء.');
                window.location.href = 'account.html';
                return;
            }

            checkLastOrder(user.uid, () => {
                paymentModal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            });
        }

        if (e.target.classList.contains('close-btn') || e.target.id === 'cancel-payment-btn') {
            closeModal();
        }

        const paymentOption = e.target.closest('.payment-option');
        if (paymentOption) {
            selectedPaymentMethod = paymentOption.textContent;
            document.querySelectorAll('.payment-details').forEach(d => d.classList.add('hidden'));
            const targetDetails = document.getElementById(`${paymentOption.dataset.method}-details`);
            if (targetDetails) targetDetails.classList.remove('hidden');
            
            document.getElementById('payment-method-title').textContent = `الدفع عبر ${selectedPaymentMethod}`;

            const contactMethods = ['stcpay', 'bank', 'paypal', 'binance', 'other-payment'];
            const isContactMethod = contactMethods.includes(paymentOption.dataset.method);
            document.getElementById('standard-checkout-flow').classList.toggle('hidden', isContactMethod);
            document.getElementById('contact-checkout-flow').classList.toggle('hidden', !isContactMethod);
            
            document.getElementById('step-1-payment-method').classList.add('hidden');
            document.getElementById('step-2-payment-instructions').classList.remove('hidden');
        }

        const confirmPaymentBtn = document.getElementById('confirm-payment-btn');
        if (e.target === confirmPaymentBtn) {
            const user = window.auth.currentUser;
            if (!user) {
                alert("الرجاء تسجيل الدخول أولاً.");
                return;
            }

            // تحقق من الكابتشا
            const recaptchaResponse = grecaptcha.getResponse();
            if (!recaptchaResponse) {
                alert('الرجاء التأكيد أنك لست برنامج روبوت.');
                return;
            }

            let paymentDetailsText = "لا توجد تفاصيل إضافية.";
            const currentMethod = document.querySelector('.payment-details:not(.hidden)');
            
            if (currentMethod) {
                switch (currentMethod.id) {
                    case 'vodafone-details':
                        const vfSenderNumber = document.getElementById('vf-sender-number').value.trim();
                        const vfAmount = document.getElementById('vf-amount').value.trim();
                        const vfTransactionId = document.getElementById('vf-transaction-id').value.trim();
                        const vfReferrer = document.getElementById('vf-referrer-code').value.trim();

                        if (vfSenderNumber === '' || vfAmount === '' || vfTransactionId === '') {
                            alert('الرجاء إدخال رقم المرسل والمبلغ ورقم العملية.');
                            return;
                        }

                        paymentDetailsText = `
                        تفاصيل فودافون كاش:
                        رقم المرسل: ${vfSenderNumber}
                        المبلغ: ${vfAmount}
                        من طرف: ${vfReferrer || 'لم يُدخل'}
                        رقم العملية: ${vfTransactionId}`;
                        break;
                    case 'sawa-details':
                        const sawaCode = document.getElementById('sawa-code').value.trim();
                        const sawaReferrer = document.getElementById('sawa-referrer-code').value.trim();
                        if (sawaCode.length < 14 || !/^\d+$/.test(sawaCode)) {
                            alert('رقم البطاقة غير صحيح.');
                            return;
                        }
                        paymentDetailsText = `
                        تفاصيل شحن سوا:
                        الرقم: ${sawaCode}
                        من طرف: ${sawaReferrer || 'لم يُدخل'}`;
                        break;
                    case 'mobily-details':
                        const mobilyCode = document.getElementById('mobily-code').value.trim();
                        const mobilyReferrer = document.getElementById('mobily-referrer-code').value.trim();
                        if (mobilyCode.length < 14 || !/^\d+$/.test(mobilyCode)) {
                            alert('رقم البطاقة غير صحيح.');
                            return;
                        }
                        paymentDetailsText = `
                        تفاصيل شحن موبايلي:
                        الرقم: ${mobilyCode}
                        من طرف: ${mobilyReferrer || 'لم يُدخل'}`;
                        break;
                    default:
                        paymentDetailsText = "لا توجد تفاصيل إضافية.";
                }
            }
            
            const templateParams = {
                user_name: user.displayName || user.email,
                user_email: user.email,
                package_name: selectedPackageName,
                package_price: selectedPackagePrice,
                payment_method: selectedPaymentMethod,
                payment_details: paymentDetailsText,
                'g-recaptcha-response': recaptchaResponse
            };

            confirmPaymentBtn.textContent = 'جارٍ إرسال طلبك...';
            confirmPaymentBtn.disabled = true;

            emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams)
                .then(() => {
                    updateLastOrder(user.uid);
                    document.getElementById('step-2-payment-instructions').classList.add('hidden');
                    document.getElementById('step-3-thank-you').classList.remove('hidden');
                    setTimeout(closeModal, 5000);
                }, (error) => {
                    alert('حدث خطأ أثناء إرسال طلبك. يرجى المحاولة مرة أخرى.');
                    console.log('FAILED...', error);
                    grecaptcha.reset();
                })
                .finally(() => {
                    confirmPaymentBtn.textContent = 'تأكيد وإرسال الطلب';
                    confirmPaymentBtn.disabled = false;
                });
        }
        
        if (e.target.id === 'music-toggle-btn') {
            const music = document.getElementById('background-music');
            if (music.paused) {
                music.play().catch(() => {});
                e.target.textContent = '🔇';
            } else {
                music.pause();
                e.target.textContent = '🔊';
            }
        }
    });
    
    paymentModal.addEventListener('click', (e) => {
        if (e.target === paymentModal) closeModal();
    });

    const checkLastOrder = async (uid, callback) => {
        try {
            const userSnapshot = await window.db.ref('users/' + uid).once('value');
            if (userSnapshot.exists()) {
                const userData = userSnapshot.val();
                const lastOrderTime = userData.lastOrderTime || 0;
                const currentTime = new Date().getTime();
                const fortyMinutes = 40 * 60 * 1000;

                if (currentTime - lastOrderTime < fortyMinutes) {
                    alert("يرجى المحاولة مرة أخرى لاحقًا.");
                    return;
                }
            }
            callback();
        } catch (error) {
            console.error("Error checking last order time:", error);
            alert("حدث خطأ ما، يرجى المحاولة مرة أخرى.");
        }
    };

    const updateLastOrder = async (uid) => {
        try {
            await window.db.ref('users/' + uid).update({
                lastOrderTime: new Date().getTime()
            });
        } catch (error) {
            console.error("Error updating last order time:", error);
        }
    };
});